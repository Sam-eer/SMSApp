Android SMS app - developed by Sameer Kumar Tiwari, NIT Agartala

List of libraries used-
SMSBroadcast receiver- To receive a broadcast message
SMSManager- To write, read, send, receive SMSs

1. SMSs are received and sent through SMSManager
2. Contains four screens -  Login, Menu, Inbox, Compose

